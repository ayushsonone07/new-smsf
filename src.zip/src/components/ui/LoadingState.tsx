interface LoadingStateProps {
  message?: string
}

export function LoadingState({
  message = 'Loading...',
}: LoadingStateProps) {
  return <div className="loading-state">{message}</div>
}
