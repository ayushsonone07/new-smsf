import {
  createRootRoute,
  createRoute,
  createRouter,
  Outlet,
  redirect,
} from '@tanstack/react-router'
import {
  requireAuth,
  requireRole,
} from './middleware/auth.middleware'
import {
  getSession,
  homeForRole,
} from './auth/session'
import { AdminLayout } from '../components/layout/AdminLayout'
import { PageLayout } from '../components/layout/PageLayout'
import { ErrorState } from '../components/ui/ErrorState'
import { DepartmentManagementPage } from '../features/departments/pages/DepartmentManagementPage'
import { DepartmentDashboardPage } from '../features/departments/pages/DepartmentDashboardPage'
import { DepartmentCustomersPage } from '../features/departments/pages/DepartmentCustomersPage'
import { DepartmentHelpCenterPage } from '../features/departments/pages/DepartmentHelpCenterPage'
import { DepartmentServicesPage } from '../features/departments/pages/DepartmentServicesPage'
import { FeaturePermissionsPage } from '../features/permissions/pages/FeaturePermissionsPage'
import { AccessTokensPage } from '../features/auth/pages/AccessTokensPage'
import { LoginPage } from '../features/auth/pages/LoginPage'
import { ForbiddenPage } from '../features/auth/pages/ForbiddenPage'
import { HeadConsoleLayout } from '../features/departments/head/pages/HeadConsoleLayout'
import { HeadIndexPage } from '../features/departments/head/pages/HeadIndexPage'
import { HeadScreenPage } from '../features/departments/head/pages/HeadScreenPage'

function pendingPage(title: string) {
  return (
    <main className="page-content">
      <div className="loading-state">
        {title} — page coming soon
      </div>
    </main>
  )
}

const rootRoute = createRootRoute({
  component: () => <Outlet />,
  notFoundComponent: () => (
    <PageLayout>
      <ErrorState
        title="Page not found"
        message="The page you are looking for does not exist."
      />
    </PageLayout>
  ),
})

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  beforeLoad: () => {
    const session = getSession()

    throw redirect({
      to: session
        ? homeForRole(session.user.role)
        : '/login',
    })
  },
})

const loginRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/login',
  component: LoginPage,
  validateSearch: (
    search: Record<string, unknown>,
  ): { token?: string } => ({
    token:
      typeof search.token === 'string'
        ? search.token
        : undefined,
  }),
  beforeLoad: () => {
    const session = getSession()

    if (session) {
      throw redirect({
        to: homeForRole(session.user.role),
      })
    }
  },
})

const authedLayoutRoute = createRoute({
  getParentRoute: () => rootRoute,
  id: '_authed',
  beforeLoad: requireAuth,
  component: () => (
    <AdminLayout>
      <Outlet />
    </AdminLayout>
  ),
})

const adminRoute = createRoute({
  getParentRoute: () => authedLayoutRoute,
  path: '/admin',
  component: DepartmentManagementPage,
  beforeLoad: requireRole('ADMIN'),
})

const departmentFeaturesRoute = createRoute({
  getParentRoute: () => authedLayoutRoute,
  path: '/admin/departments/$departmentId',
  component: FeaturePermissionsPage,
  beforeLoad: requireRole('ADMIN'),
})

const accessTokensRoute = createRoute({
  getParentRoute: () => authedLayoutRoute,
  path: '/admin/tokens',
  component: AccessTokensPage,
  beforeLoad: requireRole('ADMIN'),
})

const headLayoutRoute = createRoute({
  getParentRoute: () => rootRoute,
  id: '_head',
  component: HeadConsoleLayout,
  beforeLoad: requireRole('ADMIN', 'HEAD'),
})

const headIndexRoute = createRoute({
  getParentRoute: () => headLayoutRoute,
  path: '/head',
  component: HeadIndexPage,
})

/** Dynamic: slug comes from admin-managed feature permissions. */
const headScreenRoute = createRoute({
  getParentRoute: () => headLayoutRoute,
  path: '/head/$screen',
  component: HeadScreenPage,
})

const usersRoute = createRoute({
  getParentRoute: () => authedLayoutRoute,
  path: '/users',
  component: () => pendingPage('Users'),
  beforeLoad: requireRole(
    'ADMIN',
    'HEAD',
    'USER',
  ),
})

const forbiddenRoute = createRoute({
  getParentRoute: () => authedLayoutRoute,
  path: '/forbidden',
  component: ForbiddenPage,
})

const departmentDashboardRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/departments/$departmentId/dashboard',
  component: DepartmentDashboardPage,
})

const departmentCustomersRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/departments/$departmentId/customers',
  component: DepartmentCustomersPage,
})

const departmentHelpCenterRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/departments/$departmentId/help-center',
  component: DepartmentHelpCenterPage,
})

const departmentServicesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/departments/$departmentId/services',
  component: DepartmentServicesPage,
})

const routeTree = rootRoute.addChildren([
  indexRoute,
  loginRoute,
  headLayoutRoute.addChildren([
    headIndexRoute,
    headScreenRoute,
  ]),
  authedLayoutRoute.addChildren([
    adminRoute,
    departmentFeaturesRoute,
    accessTokensRoute,
    usersRoute,
    forbiddenRoute,
  ]),
  departmentDashboardRoute,
  departmentCustomersRoute,
  departmentHelpCenterRoute,
  departmentServicesRoute,
])

export const router = createRouter({
  routeTree,
})

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router
  }
}
